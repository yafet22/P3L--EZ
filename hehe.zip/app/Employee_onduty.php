<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee_onduty extends Model
{
    //
}
