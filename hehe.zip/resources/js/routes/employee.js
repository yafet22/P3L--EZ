import LoginView from '../views/Login/LoginView'

export const routes = [
    {
        path: '/',
        name: 'login',
        component: LoginView,  
    }
]