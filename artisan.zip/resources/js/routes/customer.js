import HomeView from '../views/Home/HomeView'

export const routes = [
    {
        path: '/',
        name: 'home',
        component: HomeView,  
    }
]