<template>
  <VApp>
    <VContent>
        <router-view />
    </VContent>
  </VApp>
</template>

<script>

</script>
