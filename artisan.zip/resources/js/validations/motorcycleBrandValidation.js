import { 
    required,
    numeric
  } from 'vuelidate/lib/validators'
  
  export default {
    form: {
      motorcycle_brand_name: { required }
    }
  }