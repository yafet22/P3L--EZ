<?php

namespace App\Exceptions;

class InvalidCredentialException extends \Exception
{
    protected $message = 'invalid_credential';
}
