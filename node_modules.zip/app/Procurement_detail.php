<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Procurement_detail extends Model
{
    //
}
