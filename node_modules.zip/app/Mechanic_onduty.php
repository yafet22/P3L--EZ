<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mechanic_onduty extends Model
{
    //
}
